#ifndef _HASH_H_
#define _HASH_H_

#include <stdint.h>

extern uint32_t hash(const char *str);

#endif /* _HASH_H_ */
