#include <stdlib.h>
#include <stdint.h>

uint32_t hash(const char *str)
{
    (void)str;
    return 0;
}
